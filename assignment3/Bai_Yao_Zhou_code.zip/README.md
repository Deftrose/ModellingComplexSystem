# daisyworldModel

SWEN90004 Assignment2
Student:
Bowen Bai 969899
Yunjia Zhou 948447
Zeming Yao 962403

How to use:

1. In the main method:
use method paraSetting method to set the parameters
use method paraSetting_extend method to set the parameters if you want to include the extension: yellow daisy
use do_exp(expName, maxtime) method to run the test and print the result as csv files: 1.filename_Temp 2.filename_daisy
use do_exp_changing(expName, maxtime) method to run the test if the solar-luminosity is changing

2. There are 6 experiments(3 for original model, 3 for extended model) tests writen in the main method.
   Just run it with java8, these tests would execute and get 12 csv files to display the temperature and daisy population.