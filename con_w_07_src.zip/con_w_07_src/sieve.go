// The Sieve of Erasthones

package main

const K = 20  // number of primes to generate

// generate a sequence of numbers beginning from 2
func producer(ch chan<- int) {

    // TODO

}

// read values from channel in to channel out
// removing those divisible by 'prime'
func filter(in <-chan int, out chan<- int, prime int) {

    // TODO

}

// Sieve of Erasthones: daisy-chain filter processes
func main() {

    // TODO

}
